# Model Authority Spec

## Goal

Freeze the authoritative model/planner hierarchy for compile-time and runtime motion decisions.

## Authority order

1. `cpp_robot_core` runtime verdict
2. vendored xCore SDK and xMateModel bindings
3. frozen family descriptor matrix
4. Python advisory fallbacks

## Required methods

The authoritative kinematic precheck is considered available only when a live xMate binding is established and the vendored SDK exposes xMateModel support. When available, the runtime compile/load path must call all of the following official methods on the same canonical plan:

- `robot.model()`
- `getJointPos`
- `jacobian`
- `getTorque`

Unavailable model authority must degrade to a warning/advisory state rather than masquerading as an authoritative pass.

## Planner primitives

- `JointMotionGenerator`
- `CartMotionGenerator`
- `FollowPosition`
